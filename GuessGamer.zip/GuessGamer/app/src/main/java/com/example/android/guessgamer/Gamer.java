package com.example.android.guessgamer;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class Gamer extends AppCompatActivity {
TextView player, info, welcome, intro;
Button ok, refresh;
EditText guess_number;
int noTrail=1;
int diff=0;
int randomNumber;
int trialLeft=0;
int guessedNumberValue=0;
Random random;
int playercount=0;
String[] playerNamesArray;
Map<String, Integer> scoreArray;
int count=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gamer);

        player=(TextView)findViewById(R.id.playerName);

        info=(TextView)findViewById(R.id.info);
        intro=(TextView)findViewById(R.id.intro);
        welcome=(TextView)findViewById(R.id.welcome);

        guess_number=(EditText)findViewById(R.id.input_number);

        ok=(Button)findViewById(R.id.ok);
        refresh=(Button)findViewById(R.id.refresh);
        refresh.setVisibility(View.GONE);

        random= new Random();
        scoreArray= new HashMap<String, Integer>();

        randomNumber=random.nextInt(10)+1;
        Intent intent = getIntent();

        playerNamesArray= intent.getStringArrayExtra("playerNamesArray");
        player.setText(" "+playerNamesArray[playercount]+" start game");
        scoreArray.put(playerNamesArray[playercount], 0);


        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intro.setText("");

                if (!guess_number.getText().toString().equals("")) {

                    guessedNumberValue = Integer.parseInt(guess_number.getText().toString());
                    diff = Math.abs(randomNumber - guessedNumberValue);

                    if (count >= 2) {
                        if(playercount>=playerNamesArray.length){
                            info.setTextColor(Color.RED);
                            info.setText("Game Over you lose");
                        }
                        if(diff==0){
                            info.setTextColor(Color.GREEN);
                            info.setText(playerNamesArray[playercount]+" Congratulations You got the Number Right");
                            scoreArray.put(playerNamesArray[playercount],2);

                        }else {
                            scoreArray.put(playerNamesArray[playercount],0);
                        }
                        ok.setVisibility(View.GONE);
                        guess_number.setVisibility(View.GONE);
                        refresh.setVisibility(View.VISIBLE);
                    } else {
                        if (diff == 0) {

                            info.setTextColor(Color.GREEN);
                            info.setText(playerNamesArray[playercount]+" Congratulations You got the Number Right");

                            if(count==0){

                                scoreArray.put(playerNamesArray[playercount],10);

                            }else if(count==1){
                                scoreArray.put(playerNamesArray[playercount],5);
                            }
                            ok.setVisibility(View.GONE);
                            refresh.setVisibility(View.VISIBLE);

                        } else if (diff > 4) {

                            info.setTextColor(Color.RED);
                            info.setText(" Woooo!! "+playerNamesArray[playercount]+" you are very far from the answer");
                        } else if (diff == 3 || diff == 4) {
                            info.setTextColor(Color.RED);
                            info.setText(" Woooo!! "+playerNamesArray[playercount]+" you are far from the answer");


                        } else {
                            info.setTextColor(Color.RED);
                            info.setText(" Chaiii!! "+playerNamesArray[playercount]+" and you are very close to the answer ooo");

                        }

                        count++;
                        guess_number.setText("");
                    }

                }
            else{

                    info.setTextColor(Color.RED);
                    info.setText(playerNamesArray[playercount]+" Enter your guessed number and press the ok button");
                }

            }
        });

        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playercount++;
                if(playercount<playerNamesArray.length){
                    count=0;
                    randomNumber=random.nextInt(10)+1;

                    info.setTextColor(Color.RED);
                    info.setText("");
                    intro.setText("I just guessed a number from the range of 1 -10\n" +
                            "        You have 3 chances to guess the number");
                    player.setText(" "+playerNamesArray[playercount]+" continue game");

                    ok.setVisibility(View.VISIBLE);
                    guess_number.setVisibility(View.VISIBLE);
                    refresh.setVisibility(View.GONE);
                    scoreArray.put(playerNamesArray[playercount],0);
                }else{
                    refresh.setVisibility(View.GONE);
                    ok.setVisibility(View.GONE);
                    info.setTextColor(Color.RED);
                    info.setText("Game Over");
                    welcome.setText("");
                    player.setText("");
                }


            }
        });



       // player.setText(Player_name);






    }
}
