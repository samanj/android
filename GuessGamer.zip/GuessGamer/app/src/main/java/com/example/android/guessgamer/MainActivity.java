package com.example.android.guessgamer;

import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.android.guessgamer.InternetData.NetworkUtils;

import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
public class MainActivity extends AppCompatActivity {
    Map<String, Integer> scoresArray= new HashMap<String, Integer>();
    EditText player_name,player_no;
    Button submitbtn, submitplayerno;
    TextView welcome;
    int playersNumber=0, count=0, toastcount=0;
    String[] playerNamesArray;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        player_name= (EditText)findViewById(R.id.insert_playername);
        player_no= (EditText)findViewById(R.id.insert_playerno);
        welcome=(TextView)findViewById(R.id.welcome);
        submitbtn=(Button)findViewById(R.id.submit_playername);
        submitplayerno=(Button)findViewById(R.id.submit_playerno);
        submitbtn.setVisibility(View.GONE);
        player_name.setVisibility(View.GONE);

        submitplayerno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!player_no.equals("")) {

                    playersNumber = Integer.parseInt(player_no.getText().toString());
                    playerNamesArray = new String[playersNumber];

                    submitbtn.setVisibility(View.VISIBLE);
                    player_name.setVisibility(View.VISIBLE);
                    player_no.setVisibility(View.GONE);
                    submitplayerno.setVisibility(View.GONE);
                }else{
                    Toast.makeText(MainActivity.this, "Enter the numbers of players expected to play", Toast.LENGTH_SHORT).show();
                }

            }
        });
        submitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(count<playersNumber){
                    playerNamesArray[count]=player_name.getText().toString();

                    if(!playerNamesArray[count].equals("")){



                        player_name.setText("");
                        toastcount=count+1;
                        if(count==(playersNumber-1)){
                            player_name.setVisibility(View.GONE);
                            submitbtn.setText("Start Game");
                            Toast.makeText(MainActivity.this, "Player Number "+toastcount+" added successfully", Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(MainActivity.this, "Player Number "+toastcount+" added successfully", Toast.LENGTH_SHORT).show();
                        }
                        count++;
                    }else{
                        Toast.makeText(MainActivity.this, "Enter a players name", Toast.LENGTH_SHORT).show();
                    }


                }else{
                    Toast.makeText(MainActivity.this, "GAME LAUNCHED", Toast.LENGTH_SHORT).show();
                    intent = new Intent(MainActivity.this, Gamer.class);
                    intent.putExtra("playerNamesArray", playerNamesArray);
                    startActivity(intent);

                }

            }
        });

    }
    void makeGithubSearchQuery(){
        String githubQuery = player_name.getText().toString();
        URL githubSearchUrl= NetworkUtils.buildUrl(githubQuery);
        welcome.setText(githubSearchUrl.toString());
        new GithubQueryTask().execute(githubSearchUrl);

    }
public class GithubQueryTask extends AsyncTask<URL, Void, String>{

    @Override
    protected String doInBackground(URL... urls) {
        String githubSearchResults=null;
        URL searchurl = urls[0];
        try {
            githubSearchResults=NetworkUtils.getResponseFromHttpUrl(searchurl);
        }catch (IOException e){
            e.printStackTrace();

        }

        return githubSearchResults;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(String s) {

        if(s!=null && !s.equals("")){
            player_name.setText(s);
        }

    }
}

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int menuItemSelectedId= item.getItemId();
        if(menuItemSelectedId==R.id.search){
            makeGithubSearchQuery();

        }
        return true;
    }
}
